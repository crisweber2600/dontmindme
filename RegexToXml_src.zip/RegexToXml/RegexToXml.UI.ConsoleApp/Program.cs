using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;
using AndrewTweddle.Tools.RegexToXml.Core;
using System.Net;

namespace AndrewTweddle.Tools.RegexToXml.UI.ConsoleApp
{
    class Program
    {
        /// <summary>
        /// Displays the available command line switches,
        /// usually in response to no arguments, the -? argument,
        /// or an error occuring while parsing arguments.
        /// </summary>
        public static void DisplayHelpText()
        {
            Console.WriteLine("RegexToXml 1.0");
            Console.WriteLine();
            Console.WriteLine("Author: Andrew Tweddle");
            Console.WriteLine();
            Console.WriteLine("Description:");
            Console.WriteLine("    Applies a regular expression to the input text");
            Console.WriteLine("    and outputs the results as XML.");
            Console.WriteLine();
            Console.WriteLine("Parameters (all optional):");
            Console.WriteLine("    -? ... print out help; must be the only command line argument.");
            Console.WriteLine("    -i <Input file or Uri>");
            Console.WriteLine("    -I <Input text>");
            Console.WriteLine("    -t <input encoding>");
            Console.WriteLine("    -r <Regular expression file>");
            Console.WriteLine("    -R <Regular expression>");
            Console.WriteLine("    -o <Xml output file>");
            Console.WriteLine("    -e <Error output file>");
            Console.WriteLine("    -d <GroupName=ElementName>");
            Console.WriteLine("       ... can repeat; remaps group names to preferred XML element names.");
            Console.WriteLine("           The document root element is <Matches> containing <Match> elements.");
            Console.WriteLine("           These names can also be remapped using the -d switch.");

            /* RegexOptions switches: */
            foreach (RegexSwitch rgxSwitch in regexSwitches)
            {
                Console.WriteLine(@"    -{0}{{+|-}} ... {1}, {2} by default",
                    rgxSwitch.switchChar, rgxSwitch.switchName, 
                    rgxSwitch.defaultValue ? "on" : "off");

                if (rgxSwitch.isInverted)
                {
                    Console.WriteLine("                NB: This maps to the inverse of RegexOptions.{0}",
                        Enum.GetName(typeof(RegexOptions), rgxSwitch.option));
                }
                else
                {
                    Console.WriteLine("                NB: This maps to RegexOptions.{0}", 
                        Enum.GetName(typeof(RegexOptions), rgxSwitch.option));
                }
            }

            Console.WriteLine("    -S{+|-} ... write start index of capture, off by default");
            Console.WriteLine("    -E{+|-} ... write end index of capture, off by default");
            Console.WriteLine("    -L{+|-} ... write length of capture, off by default");
            Console.WriteLine("    -k{+|-} ... skip unnamed capture groups, off by default");
            Console.WriteLine("                (NB: named groups nested within unnamed groups");
            Console.WriteLine("                     will always be shown).");
            Console.WriteLine("    -f{+|-} ... write xml fragment; off by default");
            Console.WriteLine("    -a{+|-} ... Append to xml output file; off by default");
            Console.WriteLine("    -v{+|-} ... verbose mode, showing progress, on by default");
            Console.WriteLine("    -p{+|-} ... prompt to exit application, off by default");
            Console.WriteLine();
            Console.WriteLine("Notes:");
            Console.WriteLine("    1. If a switch is provided multiple times, only the last instance is used.");
            Console.WriteLine("    2. If -r and -R are both specified, then -R takes precedence.");
            Console.WriteLine("       Either -r or -R must be specified.");
            Console.WriteLine("    3. If -i and -I are both specified, then -I takes precedence.");
            Console.WriteLine("       If -i and -I are omitted, then the standard input stream is used.");
            Console.WriteLine("    4. If -o is omitted, then the standard output stream is used.");
            Console.WriteLine("       Verbose mode is also turned off, regardless of the -v switch.");
            Console.WriteLine("    5. If -e is omitted, then errors are sent to the standard error stream.");
            Console.WriteLine("    6. Unnamed capture groups in the regular expression are named Group<N> ");
            Console.WriteLine("       where <N> is an integer.");
            Console.WriteLine("    7. NB: Structure the regular expression to avoid zero length captures");
            Console.WriteLine("       which can't always be placed in the XML hierarchy correctly!");
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            CommandLineOptions options = new CommandLineOptions();
            int argCount = args.Length;

            if ((argCount == 0) || ((argCount == 1) && (args[0] == "-?")))
            {
                DisplayHelpText();
            }
            else
            {
                InitialiseDefaultOptions(options);

                try
                {
                    ParseArguments(args, options);
                    GenerateXmlFile(options);
                }
                catch (Exception exc)
                {
                    Console.Error.WriteLine("*** An error occurred ***");
                    Console.Error.WriteLine(exc);
                }
            }

            if (options.PromptToExit)
            {
                Console.WriteLine();
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
            }
        }

        /// <summary>
        /// Initialises the default options prior to parsing the command line 
        /// arguments, which could overwrite some of these defaults.
        /// </summary>
        /// <param name="options">The CommandLineOptions object to initialise</param>
        private static void InitialiseDefaultOptions(CommandLineOptions options)
        {
            options.WriteStartIndex = false;
            options.WriteEndIndex = false;
            options.WriteLength = false;
            options.SkipUnnamedGroups = false;

            options.RegexOptions
                = RegexOptions.IgnoreCase
                | RegexOptions.IgnorePatternWhitespace
                | RegexOptions.Multiline;
        }

        /// <summary>
        /// Parses the arguments to initialize the command line options.
        /// </summary>
        /// <param name="args">The command line arguments 
        /// passed to the Main method.</param>
        /// <param name="options">The command line options to be set.</param>
        private static void ParseArguments(string[] args,
            CommandLineOptions options)
        {
            string setting = null;
            char currSwitch = ' ';  // A blank indicates no switch

            foreach (string arg in args)
            {
                if (arg.Length > 0)
                {
                    /* parameters starting with a dash are 
                     * always followed by a single character switch:
                     */
                    if (arg[0] == '-')
                    {
                        if (arg.Length > 1)
                        {
                            currSwitch = arg[1];
                        }
                        else
                        {
                            currSwitch = ' ';
                        }

                        /* The remainder of the parameter (after the switch)
                         * is the setting. If omitted then the setting is
                         * given by the value of the next parameter:
                         */
                        setting = arg.Substring(2);
                        if (setting.Length == 0)
                        {
                            setting = null;
                        }
                    }
                    else
                    {
                        /* This command line parameter is a setting for
                         * the previously parsed switch:
                         */
                        setting = arg;
                    }
                }

                if ((setting != null) || (currSwitch == '?'))
                {
                    bool switchFound = false;

                    foreach (RegexSwitch rgxSwitch in regexSwitches)
                    {
                        if (currSwitch == rgxSwitch.switchChar)
                        {
                            ApplyRegexSwitch(options, rgxSwitch,
                                setting);
                            switchFound = true;
                            break;
                        }
                    }

                    if (!switchFound)
                    {
                        switch (currSwitch)
                        {
                            case 'i':
                                options.InputFileNameOrUri = setting;
                                break;

                            case 'I':
                                options.InputText = setting;
                                break;

                            case 't':
                                options.InputEncoding
                                    = ParseInputEncoding(setting);
                                break;

                            case 'r':
                                options.RegexFileName = setting;
                                break;

                            case 'R':
                                options.RegexText = setting;
                                break;

                            case 'o':
                                options.OutputFileName = setting;
                                break;

                            case 'e':
                                options.ErrorFileName = setting;
                                break;

                            case 'd':
                                ParseRegexToXmlElementNameMappings(options,
                                    setting);
                                break;

                            case 'S':
                                options.WriteStartIndex = ParseBooleanSetting(
                                    'S', "write start index", setting);
                                break;

                            case 'E':
                                options.WriteEndIndex = ParseBooleanSetting(
                                    'E', "write end index", setting);
                                break;

                            case 'L':
                                options.WriteLength = ParseBooleanSetting(
                                    'L', "write length", setting);
                                break;

                            case 'k':
                                options.SkipUnnamedGroups 
                                    = ParseBooleanSetting('k', 
                                        "skip unnamed groups", setting);
                                break;

                            case 'f':
                                options.OmitXmlDeclaration
                                    = ParseBooleanSetting(
                                    'f', "write XML fragment", setting);
                                break;

                            case 'a':
                                options.AppendToOutputFile
                                    = ParseBooleanSetting(
                                    'a', "append to XML output file", setting);
                                break;

                            case 'p':
                                options.PromptToExit = ParseBooleanSetting(
                                    'p', "prompt to exit", setting);
                                break;

                            case 'v':
                                options.VerboseMode = ParseBooleanSetting(
                                    'v', "verbose mode", setting);
                                break;

                            case ' ':
                                throw new CommandLineSwitchException(
                                    String.Format(
                                        "Error: no command line switch precedes parameter: {0}",
                                        setting));

                            default:
                                throw new CommandLineSwitchException(
                                    String.Format(
                                        "Error: unrecognised switch {0}",
                                        currSwitch));
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Generates the XML file based on the command line options.
        /// </summary>
        /// <param name="options">The command line options object.</param>
        private static void GenerateXmlFile(CommandLineOptions options)
        {
            /* Initialise error stream (note that this can be null!): */
            FileStream errorLogFileStream
                = CreateErrorLogFileStream(options.ErrorFileName);

            try
            {
                /* Initialise regular expression stream: */
                if (options.RegexText == null)
                {
                    options.RegexText
                        = ReadRegexTextFromFile(options.RegexFileName);
                }

                /* Initialise input text: */
                if (options.InputText == null)
                {
                    if (options.InputFileNameOrUri != null)
                    {
                        options.InputText = ReadInputTextFromUri(
                            options.InputFileNameOrUri, options.InputEncoding);
                    }
                    else
                    {
                        /* Use the standard input stream: */
                        options.InputText = Console.In.ReadToEnd();
                    }
                }

                /* Create the XmlWriter for the outputs
                 * which will wrap a TextWriter
                 * which will either wrap the output file stream, 
                 * or the console output stream:
                 */
                FileStream outputFS;
                TextWriter outputTW;

                if (options.OutputFileName == null)
                {
                    outputFS = null;
                    outputTW = Console.Out;

                    /* If the standard output stream is being
                     * used for the output, then it can't be
                     * used to show progress information.
                     * So ensure verbose mode is disabled:
                     */
                    options.VerboseMode = false;
                }
                else
                {
                    outputFS = new FileStream(options.OutputFileName,
                        options.AppendToOutputFile 
                            ? FileMode.Append 
                            : FileMode.Create, 
                        FileAccess.Write);
                    outputTW = new StreamWriter(outputFS);
                }

                try
                {
                    using (outputTW)
                    {
                        XmlWriter xwriter = CreateXmlWriter(options, outputTW);

                        using (xwriter)
                        {
                            if (options.VerboseMode)
                            {
                                Console.WriteLine("Generating output file...");
                            }

                            /* All inputs appear to be fine, 
                             * so generate the XML output:
                             */
                            RegexToXmlConverter.Convert(xwriter, 
                                options.InputText, options.RegexText, 
                                options);
                        }

                        /* Add a new line character at the end of the XML
                         * outputs, in case multiple XML files will be
                         * appended to one another:
                         */
                        outputTW.WriteLine();
                    }
                }
                finally
                {
                    if (outputFS != null)
                    {
                        outputFS.Close();
                    }
                }

                if (options.VerboseMode)
                {
                    Console.WriteLine("Done!");
                }
            }
            catch (Exception exc)
            {
                WriteExceptionToErrorLog(errorLogFileStream, exc);

                /* Rethrow the error for the standard error stream to handle: */
                throw;
            }
            finally
            {
                if (errorLogFileStream != null)
                {
                    errorLogFileStream.Close();
                }
            }
        }

        /// <summary>
        /// Creates the error log file stream.
        /// </summary>
        /// <param name="errorLogFileName">Name of the error log file.</param>
        /// <returns></returns>
        private static FileStream CreateErrorLogFileStream(
            string errorLogFileName)
        {
            FileStream errorLogFileStream = null;

            if (errorLogFileName != null)
            {
                if (!File.Exists(errorLogFileName))
                {
                    throw new CommandLineSwitchException(
                        String.Format(
                            "Error: error log \"{0}\" could not be found!",
                            errorLogFileName));
                }

                errorLogFileStream = new FileStream(errorLogFileName,
                    FileMode.Create, FileAccess.Write, FileShare.Read);
            }

            return errorLogFileStream;
        }

        /// <summary>
        /// Creates the XML writer which will write to the output file.
        /// </summary>
        /// <param name="outputFileName">Name of the output file.</param>
        /// <returns></returns>
        private static XmlWriter CreateXmlWriter(CommandLineOptions options,
            TextWriter outputTW)
        {
            XmlWriterSettings xwSettings = new XmlWriterSettings();
            xwSettings.Indent = true;
            xwSettings.IndentChars = "    ";
            xwSettings.OmitXmlDeclaration = options.OmitXmlDeclaration;
            
            XmlWriter xwriter;
            xwriter = XmlWriter.Create(outputTW, xwSettings);

            return xwriter;
        }

        /// <summary>
        /// Reads the text from the input file or URI.
        /// This is the text which will be parsed using the regular expression.
        /// </summary>
        /// <param name="inputFileNameOrUri">The input file name or URI.</param>
        /// <param name="inputEncoding">The input file encoding.</param>
        /// <returns></returns>
        private static string ReadInputTextFromUri(string inputFileNameOrUri,
            Encoding inputEncoding)
        {
            /* If this is a relative file path, then convert it to the 
             * full path otherwise the Uri constructor will throw an error:
             */
            if (!Uri.IsWellFormedUriString(inputFileNameOrUri, 
                UriKind.Absolute))
            {
                try
                {
                    inputFileNameOrUri = Path.GetFullPath(inputFileNameOrUri);
                }
                catch
                {
                    /* Swallow the exception, since a more meaningful 
                     * exception will be thrown when the Uri is created.
                     */
                }
            }

            Uri inputUri = new Uri(inputFileNameOrUri);

            /* Read the input text from the Uri: */
            WebRequest wrq = WebRequest.Create(inputUri);
            WebResponse wresp = wrq.GetResponse();

            using (wresp)
            {
                Stream respStream = wresp.GetResponseStream();
                using (respStream)
                {
                    StreamReader sr 
                        = new StreamReader(respStream, inputEncoding);

                    return sr.ReadToEnd();
                }
            }
        }

        /// <summary>
        /// Reads the regular expression pattern from the file.
        /// </summary>
        /// <param name="regexFileName">The name of the file containing 
        /// the regular expression pattern.</param>
        /// <returns>The regular expression pattern.</returns>
        private static string ReadRegexTextFromFile(string regexFileName)
        {
            string regExFileNotFoundMessage
                = "Error: regular expression file \"{0}\" could not be found!";

            if (regexFileName != null)
            {
                if (!File.Exists(regexFileName))
                {
                    throw new CommandLineSwitchException(
                        String.Format(regExFileNotFoundMessage, regexFileName));
                }

                return File.ReadAllText(regexFileName);
            }
            else
            {
                throw new CommandLineSwitchException(
                    "No regular expression has been provided.");
            }
        }

        /// <summary>
        /// Throws an exception when an unexpected setting is encountered 
        /// while parsing the command line arguments.
        /// </summary>
        /// <param name="settingSwitch">The setting switch.</param>
        /// <param name="settingName">Name of the setting.</param>
        /// <param name="settingValue">The parsed argument value.</param>
        private static void ThrowUnexpectedSettingException(char settingSwitch,
            string settingName, string settingValue)
        {
            string unexpectedSettingsMessage
                = "Unexpected setting '{0}'.Option {1} must be followed "
                + "by + or - to indicate whether the \"{2}\" switch "
                + "is enabled or not.";

            throw new CommandLineSwitchException(
                String.Format(unexpectedSettingsMessage, 
                    settingValue, settingSwitch, settingName));
        }

        private static RegexSwitch[] regexSwitches
                = { new RegexSwitch( 
                            'c', 
                            "case sensitive regular expression",
                            RegexOptions.IgnoreCase,
                            false,  /*defaultValue*/
                            true    /*isInverted*/
                        ),
                    new RegexSwitch( 
                            'm', 
                            "multi-line regular expression",
                            RegexOptions.Multiline,
                            true,   /*defaultValue*/
                            false   /*isInverted*/
                        ),
                    new RegexSwitch( 
                            's',
                            "single-line regular expression",
                            RegexOptions.Singleline,
                            false,  /*defaultValue*/
                            false   /*isInverted*/
                        ),
                    new RegexSwitch( 
                            'w', 
                            "whitespace is part of the regular expression",
                            RegexOptions.IgnorePatternWhitespace,
                            false,   /*defaultValue*/
                            true    /*isInverted*/
                        ),
                    new RegexSwitch( 
                            'n', 
                            "use culture invariant regular expression",
                            RegexOptions.CultureInvariant,
                            false,   /*defaultValue*/
                            false    /*isInverted*/
                        ),
                    new RegexSwitch( 
                            'x', 
                            "explicit capture groups in regular expression",
                            RegexOptions.ExplicitCapture,
                            false,   /*defaultValue*/
                            false    /*isInverted*/
                        ),
                    new RegexSwitch( 
                            'y', 
                            "compiled regular expression",
                            RegexOptions.Compiled,
                            false,   /*defaultValue*/
                            false    /*isInverted*/
                        ),
                    new RegexSwitch( 
                            'z', 
                            "parse regular expression from right to left",
                            RegexOptions.RightToLeft,
                            false,   /*defaultValue*/
                            false    /*isInverted*/
                        )
                  };

        /// <summary>
        /// Applies a regular expression setting to the conversion options.
        /// </summary>
        /// <param name="options">The conversion options.</param>
        /// <param name="switchOption">The regular expression setting 
        /// to be applied or removed.</param>
        /// <param name="settingSwitch">The setting switch.</param>
        /// <param name="settingName">Name of the setting.</param>
        /// <param name="settingValue">The value of the regular expression 
        /// setting (+ or -).</param>
        /// <param name="inverted">if set to <c>true</c> then the value is 
        /// inverted, so + means to disable the regular expression setting,
        /// instead of to enable it.</param>
        private static void ApplyRegexSwitch(RegexToXmlOptions options,
            RegexOptions switchOption, char settingSwitch,
            string settingName, string settingValue, bool inverted)
        {
            bool removeOption
                = ((settingValue == "+") && inverted)
                    || ((settingValue == "-") && !inverted);
            bool addOption
                = ((settingValue == "-") && inverted)
                    || ((settingValue == "+") && !inverted);

            if (removeOption)
            {
                options.RegexOptions = options.RegexOptions & ~switchOption;
            }
            else
                if (addOption)
                {
                    options.RegexOptions = options.RegexOptions | switchOption;
                }
                else
                {
                    ThrowUnexpectedSettingException(settingSwitch,
                        settingName, settingValue);
                }
        }

        /// <summary>
        /// Applies a regular expression setting to the conversion options.
        /// </summary>
        /// <param name="options">The conversion options.</param>
        /// <param name="rgxSwitch">The RegexSwitch structure 
        /// containing metadata about the switch.</param>
        /// <param name="settingValue">The value of the regular expression 
        /// setting (+ or -).</param>
        private static void ApplyRegexSwitch(RegexToXmlOptions options,
            RegexSwitch rgxSwitch, string settingValue)
        {
            ApplyRegexSwitch(options, rgxSwitch.option, 
                rgxSwitch.switchChar, rgxSwitch.switchName,
                settingValue, rgxSwitch.isInverted);
        }

        /// <summary>
        /// Applies a regular expression setting to the conversion options.
        /// </summary>
        /// <param name="options">The conversion options.</param>
        /// <param name="switchOption">The regular expression setting 
        /// to be applied or removed.</param>
        /// <param name="settingSwitch">The setting switch.</param>
        /// <param name="settingName">Name of the setting.</param>
        /// <param name="settingValue">The value of the regular expression 
        /// setting (+ or -).</param>
        private static void ApplyRegexSwitch(RegexToXmlOptions options,
            RegexOptions switchOption, char settingSwitch,
            string settingName, string settingValue)
        {
            ApplyRegexSwitch(options, switchOption, settingSwitch,
                settingName, settingValue, false /*Inverted*/);
        }

        /// <summary>
        /// Applies a regular expression setting to the conversion options
        /// by removing the regular expression option instead of adding it
        /// if the value is +, or vice versa if it is -.
        /// </summary>
        /// <param name="options">The conversion options.</param>
        /// <param name="switchOption">The regular expression setting 
        /// to be applied or removed.</param>
        /// <param name="settingSwitch">The setting switch.</param>
        /// <param name="settingName">Name of the setting.</param>
        /// <param name="settingValue">The value of the regular expression 
        /// setting (+ or -).</param>
        private static void ApplyInvertedRegexSwitch(RegexToXmlOptions options,
            RegexOptions switchOption, char settingSwitch,
            string settingName, string settingValue)
        {
            ApplyRegexSwitch(options, switchOption, settingSwitch,
                settingName, settingValue, true /*Inverted*/);
        }

        /// <summary>
        /// Parses the boolean setting, returning true or false depending
        /// on whether the switch is followed by a + or -.
        /// </summary>
        /// <param name="settingSwitch">The switch.</param>
        /// <param name="settingName">Name of the setting.</param>
        /// <param name="setting">The setting to parse (+ or -).</param>
        /// <returns></returns>
        private static bool ParseBooleanSetting(char settingSwitch, 
            string settingName, string setting)
        {
            if (setting == "+")
            {
                return true;
            }
            else
                if (setting == "-")
                {
                    return false;
                }
                else
                {
                    ThrowUnexpectedSettingException(settingSwitch,
                        settingName, setting);

                    return false;
                        /* Just to prevent a compiler error message:
                         * "not all code paths return a value".
                         */
                }
        }

        /// <summary>
        /// Parses the input encoding command line switch.
        /// </summary>
        /// <param name="setting">The code page name or number. </param>
        /// <returns></returns>
        private static Encoding ParseInputEncoding(string setting)
        {
            int codePage = -1;

            if (int.TryParse(setting, out codePage))
            {
                return Encoding.GetEncoding(codePage);
            }
            else
            {
                return Encoding.GetEncoding(setting);
            }
        }

        /// <summary>
        /// Parses a single mapping from a regular expression 
        /// capture group name to an XML element name.
        /// </summary>
        /// <param name="options">The options.</param>
        /// <param name="setting">The setting.</param>
        private static void ParseRegexToXmlElementNameMappings(
            RegexToXmlOptions options, string setting)
        {
            /* TODO: Support multiple semi-colon delimited mappings: */
            string pattern = "^(?<groupName>[^=]+)=(?<xmlName>.*)$";
            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
            Match mat = rgx.Match(setting);

            if (!mat.Success)
            {
                throw new CommandLineSwitchException(
                    String.Format("Invalid XML element mapping: {0}", setting));
            }

            string groupName = mat.Groups["groupName"].Value;
            string xmlName = mat.Groups["xmlName"].Value;
            options.AddXmlNameConversion(groupName, xmlName);
        }

        /// <summary>
        /// Writes the exception to the error log.
        /// </summary>
        /// <param name="errorFileStream">The error file stream.</param>
        /// <param name="exc">The exception.</param>
        private static void WriteExceptionToErrorLog(
            FileStream errorFileStream, Exception exc)
        {
            if (errorFileStream != null)
            {
                StreamWriter errorWriter = new StreamWriter(errorFileStream);
                errorWriter.WriteLine("*** An error occurred ***");
                errorWriter.WriteLine(exc);
                errorWriter.Flush();
            }
        }

    }
}
