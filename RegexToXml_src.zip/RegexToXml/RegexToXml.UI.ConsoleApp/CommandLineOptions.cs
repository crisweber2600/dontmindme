using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using AndrewTweddle.Tools.RegexToXml.Core;

namespace AndrewTweddle.Tools.RegexToXml.UI.ConsoleApp
{
    public class CommandLineOptions: RegexToXmlOptions
    {
        #region private member variables

        private bool promptToExit;
        private bool verboseMode = true;
        private bool omitXmlDeclaration;
        private bool appendToOutputFile;
        private string inputFileNameOrUri;
        private string inputText;
        private string regexFileName;
        private string regexText;
        private string outputFileName;
        private string errorFileName;
        private Encoding inputEncoding = Encoding.Default;

        #endregion

        #region public properties

        public bool OmitXmlDeclaration
        {
            get { return omitXmlDeclaration; }
            set { omitXmlDeclaration = value; }
        }

        public bool AppendToOutputFile
        {
            get { return appendToOutputFile; }
            set { appendToOutputFile = value; }
        }

        public bool PromptToExit
        {
            get { return promptToExit; }
            set { promptToExit = value; }
        }

        public bool VerboseMode
        {
            get { return verboseMode; }
            set { verboseMode = value; }
        }

        public Encoding InputEncoding
        {
            get { return inputEncoding; }
            set { inputEncoding = value; }
        }

        public string InputFileNameOrUri
        {
            get { return inputFileNameOrUri; }
            set { inputFileNameOrUri = value; }
        }

        public string InputText
        {
            get { return inputText; }
            set { inputText = value; }
        }

        public string RegexFileName
        {
            get { return regexFileName; }
            set { regexFileName = value; }
        }

        public string RegexText
        {
            get { return regexText; }
            set { regexText = value; }
        }

        public string OutputFileName
        {
            get { return outputFileName; }
            set { outputFileName = value; }
        }

        public string ErrorFileName
        {
            get { return errorFileName; }
            set { errorFileName = value; }
        }

        #endregion

        #region constructors

        public CommandLineOptions(): base()
        {
        }

        public CommandLineOptions(RegexOptions regexOptions)
            : base(regexOptions)
        {
        }

        public CommandLineOptions(RegexOptions regexOptions, 
            bool skipUnnamedGroups) 
            : base(regexOptions, skipUnnamedGroups)
        {
        }

        #endregion

    }
}
