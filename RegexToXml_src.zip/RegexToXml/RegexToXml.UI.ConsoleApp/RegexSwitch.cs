using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace AndrewTweddle.Tools.RegexToXml.UI.ConsoleApp
{
    internal struct RegexSwitch
    {
        public char switchChar;
        public string switchName;
        public RegexOptions option;
        public bool defaultValue;
        public bool isInverted;

        public RegexSwitch(char switchChar, string switchName,
            RegexOptions option)
        {
            this.switchChar = switchChar;
            this.switchName = switchName;
            this.option = option;
            defaultValue = false;
            isInverted = false;
        }

        public RegexSwitch(char switchChar, string switchName,
            RegexOptions option, bool defaultValue)
            : this(switchChar, switchName, option)
        {
            this.defaultValue = defaultValue;
        }

        public RegexSwitch(char switchChar, string switchName,
            RegexOptions option, bool defaultValue, bool isInverted)
            : this(switchChar, switchName, option, defaultValue)
        {
            this.isInverted = isInverted;
        }
    }

}
