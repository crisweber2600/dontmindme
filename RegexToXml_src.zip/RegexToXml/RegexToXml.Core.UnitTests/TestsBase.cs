using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Xml;
using NUnit.Framework;
using System.Reflection;

namespace AndrewTweddle.Tools.RegexToXml.Core.UnitTests
{
    public class TestsBase
    {
        public string GetTestMethodName()
        {
            StackTrace st = new StackTrace();
            MethodBase testMethod = null;

            /* Find the most recent method in the call stack 
             * which has an NUnit [Test] attribute:
             */
            foreach (StackFrame sf in st.GetFrames())
            {
                MethodBase currMethod = sf.GetMethod();

                if (currMethod.GetCustomAttributes(typeof(TestAttribute), true)
                    .Length > 0)
                {
                    testMethod = currMethod;
                    break;
                }
            }

            if (testMethod == null)
                return "<Unknown calling method>";
            else
                return testMethod.Name;
        }

        public void WriteTestHeadingToConsole()
        {
            string methodName = GetTestMethodName();
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("*** {0} ***", methodName);
            Console.WriteLine();
        }

        public void CompareToExpectedXml(string input, string pattern, 
            string expectedXml, RegexToXmlOptions options, string notes)
        {
            WriteTestHeadingToConsole();

            if ((notes != null) && (notes != String.Empty))
            {
                Console.WriteLine("Notes:");
                Console.WriteLine("------");
                Console.WriteLine();
                Console.WriteLine(notes);
                Console.WriteLine();
            }

            Console.WriteLine("Input:");
            Console.WriteLine("------");
            Console.WriteLine();
            Console.WriteLine(input);
            Console.WriteLine();

            Console.WriteLine("Regex:");
            Console.WriteLine("------");
            Console.WriteLine();
            Console.WriteLine(pattern);
            Console.WriteLine();

            Console.WriteLine("Xml output:");
            Console.WriteLine("-----------");
            Console.WriteLine();

            XmlWriterSettings xwSettings = new XmlWriterSettings();
            xwSettings.Indent = true;
            xwSettings.IndentChars = "    ";

            string xmlOutput
                = RegexToXmlConverter.ConvertToXmlString(input, pattern,
                    options, xwSettings);

            Console.WriteLine(xmlOutput);
            Console.WriteLine();

            Assert.IsTrue(String.Compare(xmlOutput, expectedXml,
                true /*ignoreCase*/) == 0);
        }

        public void CompareToExpectedXml(string input, string pattern,
            string expectedXml, RegexToXmlOptions options)
        {
            CompareToExpectedXml(input, pattern, expectedXml,
                options, String.Empty);
        }

        public void CompareToExpectedXml(string input, string pattern,
            string expectedXml)
        {
            CompareToExpectedXml(input, pattern, expectedXml,
                new RegexToXmlOptions(), String.Empty);
        }
    }
}
