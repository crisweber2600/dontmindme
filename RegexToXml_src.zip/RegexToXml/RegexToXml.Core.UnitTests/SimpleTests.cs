using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace AndrewTweddle.Tools.RegexToXml.Core.UnitTests
{
    [TestFixture]
    public class SimpleTests : TestsBase
    {
        [Test]
        public void TestSimpleMatchUsingDefaults()
        {
            string input = "1. Man\r\n2. Woman\r\nText to ignore\r\n3.Child";
            string pattern = @"(?<Number>\d+)\.\s*(?<Item>(?:(?!\r|\n).)*)";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match>
        <Number>1</Number>
        <Item>Man</Item>
    </Match>
    <Match>
        <Number>2</Number>
        <Item>Woman</Item>
    </Match>
    <Match>
        <Number>3</Number>
        <Item>Child</Item>
    </Match>
</Matches>";

            CompareToExpectedXml(input, pattern, expectedXml);
        }

        [Test]
        public void TestSimpleMatchWithFullPositionalInfo()
        {
            string input = "1. Man\r\n2. Woman\r\nText to ignore\r\n3.Child";
            string pattern = @"(?<Number>\d+)\.\s*(?<Item>(?:(?!\r|\n).)*)";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match StartIndex=""0"" EndIndex=""5"" Length=""6"">
        <Number StartIndex=""0"" EndIndex=""0"" Length=""1"">1</Number>
        <Item StartIndex=""3"" EndIndex=""5"" Length=""3"">Man</Item>
    </Match>
    <Match StartIndex=""8"" EndIndex=""15"" Length=""8"">
        <Number StartIndex=""8"" EndIndex=""8"" Length=""1"">2</Number>
        <Item StartIndex=""11"" EndIndex=""15"" Length=""5"">Woman</Item>
    </Match>
    <Match StartIndex=""34"" EndIndex=""40"" Length=""7"">
        <Number StartIndex=""34"" EndIndex=""34"" Length=""1"">3</Number>
        <Item StartIndex=""36"" EndIndex=""40"" Length=""5"">Child</Item>
    </Match>
</Matches>";

            RegexToXmlOptions options = new RegexToXmlOptions();
            options.WriteStartIndex = true;
            options.WriteEndIndex = true;
            options.WriteLength = true;

            CompareToExpectedXml(input, pattern, expectedXml, options);
        }

        [Test]
        public void TestSimpleMatchWithRenamedElements()
        {
            string input = "1. Man\r\n2. Woman\r\n3.Child\r\nText to ignore";
            string pattern = @"(?<Number>\d+)\.\s*(?<Item>(?:(?!\r|\n).)*)";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<RootElement>
    <List>
        <ItemNumber>1</ItemNumber>
        <ListItem>Man</ListItem>
    </List>
    <List>
        <ItemNumber>2</ItemNumber>
        <ListItem>Woman</ListItem>
    </List>
    <List>
        <ItemNumber>3</ItemNumber>
        <ListItem>Child</ListItem>
    </List>
</RootElement>";

            RegexToXmlOptions options = new RegexToXmlOptions();
            options.AddXmlNameConversion("Matches", "RootElement");
            options.AddXmlNameConversion("Match", "List");
            options.AddXmlNameConversion("Number", "ItemNumber");
            options.AddXmlNameConversion("Item", "ListItem");

            CompareToExpectedXml(input, pattern, expectedXml, options);
        }

        [Test]
        public void TestSimpleMatchWithNestedCaptures()
        {
            string input = "1. Man\r\n2. Woman\r\nText to ignore\r\n3.Child";
            string pattern
                = @"(?<List>(?<Number>\d+)\.\s*(?<Item>(?:(?!\r|\n).)*))";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match>
        <List>
            <Text>1. Man</Text>
            <Number>1</Number>
            <Item>Man</Item>
        </List>
    </Match>
    <Match>
        <List>
            <Text>2. Woman</Text>
            <Number>2</Number>
            <Item>Woman</Item>
        </List>
    </Match>
    <Match>
        <List>
            <Text>3.Child</Text>
            <Number>3</Number>
            <Item>Child</Item>
        </List>
    </Match>
</Matches>";

            CompareToExpectedXml(input, pattern, expectedXml);
        }

        [Test]
        public void TestSimpleMatchWithUnnamedGroups()
        {
            string input = "1. Man\r\n2. Woman\r\nText to ignore\r\n3.Child";
            string pattern = @"((\d+)\.\s*((?:(?!\r|\n).)*))";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match>
        <Group1>
            <Text>1. Man</Text>
            <Group2>1</Group2>
            <Group3>Man</Group3>
        </Group1>
    </Match>
    <Match>
        <Group1>
            <Text>2. Woman</Text>
            <Group2>2</Group2>
            <Group3>Woman</Group3>
        </Group1>
    </Match>
    <Match>
        <Group1>
            <Text>3.Child</Text>
            <Group2>3</Group2>
            <Group3>Child</Group3>
        </Group1>
    </Match>
</Matches>";

            CompareToExpectedXml(input, pattern, expectedXml);
        }

        [Test]
        public void TestSimpleMatchWithNamedAndUnnamedGroups()
        {
            string input = "1. Man\r\n2. Woman\r\nText to ignore\r\n3.Child";
            string pattern = @"(?<List>(\d+)\.\s*(?<Item>(?:(?!\r|\n).)*))";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match>
        <List>
            <Text>1. Man</Text>
            <Group1>1</Group1>
            <Item>Man</Item>
        </List>
    </Match>
    <Match>
        <List>
            <Text>2. Woman</Text>
            <Group1>2</Group1>
            <Item>Woman</Item>
        </List>
    </Match>
    <Match>
        <List>
            <Text>3.Child</Text>
            <Group1>3</Group1>
            <Item>Child</Item>
        </List>
    </Match>
</Matches>";

            CompareToExpectedXml(input, pattern, expectedXml);
        }

        [Test]
        public void TestSimpleMatchWithSkippingOfUnnamedGroups()
        {
            string input = "1. Man\r\n2. Woman\r\nText to ignore\r\n3.Child";
            string pattern = @"(?<List>(\d+)\.\s*(?<Item>(?:(?!\r|\n).)*))";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match>
        <List>
            <Text>1. Man</Text>
            <Item>Man</Item>
        </List>
    </Match>
    <Match>
        <List>
            <Text>2. Woman</Text>
            <Item>Woman</Item>
        </List>
    </Match>
    <Match>
        <List>
            <Text>3.Child</Text>
            <Item>Child</Item>
        </List>
    </Match>
</Matches>";

            RegexToXmlOptions options = new RegexToXmlOptions();
            options.SkipUnnamedGroups = true;
            CompareToExpectedXml(input, pattern, expectedXml, options);
        }

        [Test]
        public void TestNestedIdenticalCaptures()
        {
            string input = "1234";
            string pattern
                = @"(?<Outer>(?<Inner>\d))";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match>
        <Outer>
            <Text>1</Text>
            <Inner>1</Inner>
        </Outer>
    </Match>
    <Match>
        <Outer>
            <Text>2</Text>
            <Inner>2</Inner>
        </Outer>
    </Match>
    <Match>
        <Outer>
            <Text>3</Text>
            <Inner>3</Inner>
        </Outer>
    </Match>
    <Match>
        <Outer>
            <Text>4</Text>
            <Inner>4</Inner>
        </Outer>
    </Match>
</Matches>";

            RegexToXmlOptions options = new RegexToXmlOptions();
            CompareToExpectedXml(input, pattern, expectedXml, options);

            Console.WriteLine();
            Console.WriteLine(
                ">>> NB: This works, but it depends on an internal detail of the Regex implementation.");
            Console.WriteLine(
                ">>>     Regex.GetGroupNames() must return groups in the same order as in the regular expression!");
            Console.WriteLine();
        }

        [Test]
        public void DemonstrateZeroWidthCaptureProblems()
        {
            string input = "12,3,4";
            string pattern
                = @"(?<Number>(?<Tens>[1-9]?)(?<Units>\d))(?:,|\z)";
            string expectedXml
                = @"<?xml version=""1.0"" encoding=""utf-16""?>
<Matches>
    <Match Length=""3"">
        <Number Length=""2"">
            <Text>12</Text>
            <Tens Length=""1"">1</Tens>
            <Units Length=""1"">2</Units>
        </Number>
    </Match>
    <Match Length=""2"">
        <Number Length=""1"">
            <Text>3</Text>
            <Units Length=""1"">
                <Text>3</Text>
                <Tens Length=""0""></Tens>
            </Units>
        </Number>
    </Match>
    <Match Length=""1"">
        <Number Length=""1"">
            <Text>4</Text>
            <Units Length=""1"">
                <Text>4</Text>
                <Tens Length=""0""></Tens>
            </Units>
        </Number>
    </Match>
</Matches>";

            RegexToXmlOptions options = new RegexToXmlOptions();
            options.WriteLength = true;
            CompareToExpectedXml(input, pattern, expectedXml, options);

            Console.WriteLine();
            Console.WriteLine(
                ">>> Zero width captures become child nodes of other capture elements into which they fit.");
            Console.WriteLine(
                ">>> This happens even when they should be a sibling node instead!");
            Console.WriteLine();
        }
    }
}
