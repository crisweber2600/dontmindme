using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace AndrewTweddle.Tools.RegexToXml.Core
{
    public class RegexToXmlOptions
    {
        #region private variables

        private RegexOptions regexOptions
            = RegexOptions.IgnoreCase
            | RegexOptions.IgnorePatternWhitespace
            | RegexOptions.Multiline;

        private bool skipUnnamedGroups;
        private bool writeStartIndex;
        private bool writeEndIndex;
        private bool writeLength;

        private Dictionary<string, string> xmlNames;
        #endregion

        #region public properties

        public bool SkipUnnamedGroups
        {
          get { return skipUnnamedGroups; }
          set { skipUnnamedGroups = value; }
        }

        public RegexOptions RegexOptions
        {
            get { return regexOptions; }
            set { regexOptions = value; }
        }

        public bool WriteStartIndex
        {
            get { return writeStartIndex; }
            set { writeStartIndex = value; }
        }

        public bool WriteEndIndex
        {
            get { return writeEndIndex; }
            set { writeEndIndex = value; }
        }

        public bool WriteLength
        {
            get { return writeLength; }
            set { writeLength = value; }
        }

        public Dictionary<string, string> XmlNames
        {
            get 
            {
                if (xmlNames == null)
                {
                    xmlNames = new Dictionary<string, string>();
                }
                return xmlNames; 
            }
        }

        #endregion

        #region constructors

        public RegexToXmlOptions()
        {
        }

        public RegexToXmlOptions(RegexOptions regexOptions)
            : this()
        {
            this.regexOptions = regexOptions;
        }

        public RegexToXmlOptions(RegexOptions regexOptions,
            bool skipUnnamedGroups) 
            : this(regexOptions)
        {
            this.skipUnnamedGroups = skipUnnamedGroups;
        }

        #endregion

        /// <summary>
        /// Converts the group name (or other input name)
        /// to an XML element name stored in XmlNames.
        /// </summary>
        /// <param name="name">The group name (or other input name).</param>
        /// <returns>The name of the XML element.</returns>
        public string ConvertedXmlName(string name)
        {
            if (XmlNames.ContainsKey(name))
            {
                return XmlNames[name];
            }
            else
            {
                /* There is no conversion registered for this element.
                 * Just use the default name:
                 */
                return name;
            }
        }

        /// <summary>
        /// Tries to convert the group name (or other input name)
        /// to an XML element name stored in XmlNames.
        /// </summary>
        /// <param name="inputName">The group name or other input name.</param>
        /// <param name="xmlName">Name which will be assigned to the XML element.</param>
        /// <returns></returns>
        public bool TryConvertToXmlName(string inputName, ref string xmlName)
        {
            bool canConvert = XmlNames.ContainsKey(inputName);

            if (canConvert)
            {
                xmlName = XmlNames[inputName];
            }

            return canConvert;
        }

        /// <summary>
        /// Adds a mapping from the name of the regex capture group 
        /// to the XML element name.
        /// </summary>
        /// <param name="inputName">Name of the input.</param>
        /// <param name="xmlName">Name of the XML.</param>
        public void AddXmlNameConversion(string inputName,
            string xmlName)
        {
            if (XmlNames.ContainsKey(inputName))
            {
                XmlNames[inputName] = xmlName;
            }
            else
            {
                XmlNames.Add(inputName, xmlName);
            }
        }
    }
}
