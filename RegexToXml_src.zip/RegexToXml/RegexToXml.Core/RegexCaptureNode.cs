using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;

namespace AndrewTweddle.Tools.RegexToXml.Core
{
    internal class RegexCaptureNode
    {
        #region private variables

        private bool isMatch;
        private Capture thisCapture;
        private string groupName;
        private List<RegexCaptureNode> childNodes
            = new List<RegexCaptureNode>();

        #endregion

        #region public properties

        public bool IsMatch
        {
            get { return isMatch; }
        }

        public Capture ThisCapture
        {
            get { return thisCapture; }
        }

        public string GroupName
        {
            get { return groupName; }
        }

        public int Index
        {
            get { return thisCapture.Index; }
        }

        public int Length
        {
            get { return thisCapture.Length; }
        }

        public int EndIndex
        {
            get { return thisCapture.Index + thisCapture.Length - 1; }
        }

        public ReadOnlyCollection<RegexCaptureNode> ChildNodes
        {
            get { return new ReadOnlyCollection<RegexCaptureNode>(childNodes); }
        }

        public RegexCaptureNode this[int i]
        {
            get
            {
                return childNodes[i];
            }
        }

        #endregion

        public void AddChildNode(RegexCaptureNode newChildCaptureNode)
        {
            bool childAdded = false;
            bool newChildAsParentMode = false;

            /* Add a check that the child's index range shouldn't 
             * actually make it the parent of the parent: */
            if ((newChildCaptureNode.Index <= Index)
                && (newChildCaptureNode.EndIndex >= EndIndex)
                && !((newChildCaptureNode.Index == Index)
                    && (newChildCaptureNode.EndIndex == EndIndex)))
            {
                throw new RegexToXmlConversionException(
                    "A child capture's indices completely cover its parent's index range.");
            }

            foreach (RegexCaptureNode childCaptureNode in childNodes)
            {
                /* If the new node is completely contained within the 
                 * existing child node, then recursively add the new child
                 * node as a child of the existing child node:
                 * 
                 * NB: This will also be the case if the 2 nodes have
                 * identical ranges. In this case the capture node added
                 * second is added as a child of the capture node added
                 * first. 
                 * 
                 * This rule is more likely to lead to consistent
                 * hierarchies, since there are situations where a group 
                 * will sometimes be properly contained within the parent group, 
                 * and sometimes it may have the same range as the parent group
                 * (e.g. if there are other optional capture groups within
                 * the parent group).
                 */
                if ((newChildCaptureNode.Index >= childCaptureNode.Index)
                    && (newChildCaptureNode.EndIndex 
                        <= childCaptureNode.EndIndex))
                {
                    childCaptureNode.AddChildNode(newChildCaptureNode);
                    childAdded = true;
                    break;
                }

                /* If the new node falls before the existing child node
                 * but does not contain the existing child node, then
                 * insert it before the existing child node:
                 */
                if ((newChildCaptureNode.Index < childCaptureNode.Index)
                    && (newChildCaptureNode.EndIndex 
                        < childCaptureNode.EndIndex))
                {
                    /* Insert the new child node before the existing one: */
                    childNodes.Insert(childNodes.IndexOf(childCaptureNode),
                        newChildCaptureNode);
                    childAdded = true;
                    break;
                }

                /* If the new capture node completely encapsulates the existing 
                 * child node, then add the existing child node as a child of 
                 * the new capture.
                 * Then switch to newChildAsParentNode, so as to keep on 
                 * checking for more of the existing child nodes which 
                 * should also be made children of the new child node:
                 */
                if ((newChildCaptureNode.Index <= childCaptureNode.Index)
                    && (newChildCaptureNode.EndIndex 
                        >= childCaptureNode.EndIndex))
                {
                    newChildCaptureNode.AddChildNode(childCaptureNode);
                    childNodes.Insert(childNodes.IndexOf(childCaptureNode),
                        newChildCaptureNode);
                    childNodes.Remove(childCaptureNode);
                    childAdded = true;
                    newChildAsParentMode = true;
                    break;
                }

                /* The remaining case is that the new child node 
                 * overlaps the existing child node's end index, or 
                 * it falls completely after the existing child node. 
                 * In these cases one can just skip to the next node.
                 */
            }

            /* If the child hasn't been added yet, then it must
             * come after all existing child nodes. 
             * In this case, simply add it to the end of the list:
             */
            if (!childAdded)
            {
                childNodes.Add(newChildCaptureNode);
            }

            if (newChildAsParentMode)
            {
                /* Work through the list in reverse order, so as not to affect 
                 * the position in the list of the next child node to be tested:
                 */
                for (int i = childNodes.Count - 1; i >= 0; i--)
                {
                    RegexCaptureNode childCaptureNode = childNodes[i];

                    /* Stop checking once the new child node is found: */
                    if (childCaptureNode == newChildCaptureNode)
                    {
                        break;
                    }

                    /* Check if still after the last of the 
                     * candidate child nodes: 
                     */
                    if ((childCaptureNode.EndIndex 
                        <= newChildCaptureNode.EndIndex) 
                        && (childCaptureNode.Index > childCaptureNode.Index))
                    {
                        childNodes.RemoveAt(i);
                        newChildCaptureNode.AddChildNode(childCaptureNode);
                    }
                }
            }
        }

        public void AddChildCapture(Capture newChildCapture, string groupName)
        {
            RegexCaptureNode newChildCaptureNode
                = new RegexCaptureNode(newChildCapture, groupName);
            AddChildNode(newChildCaptureNode);
        }

        #region constructors

        public RegexCaptureNode(Capture thisCapture, string groupName)
        {
            this.thisCapture = thisCapture;
            this.groupName = groupName;
        }

        public RegexCaptureNode(Capture thisCapture, string groupName,
            bool isMatch): this(thisCapture, groupName)
        {
            this.isMatch = isMatch;
        }

        #endregion
    }
}
