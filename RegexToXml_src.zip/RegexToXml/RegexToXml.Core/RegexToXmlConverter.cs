using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace AndrewTweddle.Tools.RegexToXml.Core
{
    public static class RegexToXmlConverter
    {
        public static void Convert(XmlWriter xw, string input,
            string regexPattern, RegexToXmlOptions options)
        {
            if (xw == null)
            {
                throw new RegexToXmlConversionException(
                    "The conversion cannot take place as the XML writer is null");
            }

            /* Construct a default set of options if options is null: */
            if (options == null)
            {
                options = new RegexToXmlOptions();
            }

            xw.WriteStartDocument();
            xw.WriteStartElement(options.ConvertedXmlName("Matches"));

            Regex rgx = new Regex(regexPattern, options.RegexOptions);
            string[] groupNames = rgx.GetGroupNames();

            Match mat = rgx.Match(input);

            while (mat.Success)
            {
                RegexCaptureNode matchNode
                    = CreateHierarchyForMatch(mat, groupNames);

                /* Recursively write out the tree in XML format: */
                WriteXmlHierarchy(xw, options, matchNode);

                mat = mat.NextMatch();
            }

            xw.WriteEndElement();
            xw.WriteEndDocument();
            xw.Flush();
        }

        public static void Convert(XmlWriter xw, string input,
            string regexPattern)
        {
            RegexToXmlOptions options = new RegexToXmlOptions();
            Convert(xw, input, regexPattern, options);
        }

        public static string ConvertToXmlString(string input,
            string regexPattern, RegexToXmlOptions options, 
            XmlWriterSettings settings)
        {
            StringBuilder sb = new StringBuilder();
            XmlWriter xw = XmlWriter.Create(sb, settings);
            Convert(xw, input, regexPattern, options);
            xw.Flush();
            return sb.ToString();
        }

        public static string ConvertToXmlString(string input,
            string regexPattern, XmlWriterSettings settings)
        {
            return ConvertToXmlString(input, regexPattern,
                new RegexToXmlOptions(), settings);
        }

        public static string ConvertToXmlString(string input,
            string regexPattern)
        {
            XmlWriterSettings xwSettings = new XmlWriterSettings();
            xwSettings.Indent = true;
            xwSettings.IndentChars = "    ";
            return ConvertToXmlString(input, regexPattern, xwSettings);
        }

        public static string ConvertToXmlString(string input,
            string regexPattern, RegexToXmlOptions options)
        {
            XmlWriterSettings xwSettings = new XmlWriterSettings();
            xwSettings.Indent = true;
            xwSettings.IndentChars = "    ";
            return ConvertToXmlString(input, regexPattern, options, 
                xwSettings);
        }

        private static RegexCaptureNode CreateHierarchyForMatch(
            Match mat, string[] groupNames)
        {
            /* Build a tree of capture nodes: */
            RegexCaptureNode matchNode 
                = new RegexCaptureNode(mat, "Match", true /*isMatch*/);

            foreach (string groupName in groupNames)
            {
                Group group = mat.Groups[groupName];

                if ((group == null) || (group == mat))
                {
                    continue;
                }

                /* A group may contain multiple captures,
                 * and these captures may fall in different branches
                 * of the hierarchy (because of being nested within
                 * other groups with multiple captures). 
                 * So don't add the group itself to the hierarchy -
                 * only add its captures:
                 */
                foreach (Capture cap in group.Captures)
                {
                    matchNode.AddChildCapture(cap, groupName);
                }
            }

            return matchNode;
        }

        private static void WriteXmlHierarchy(XmlWriter xw,
            RegexToXmlOptions options, RegexCaptureNode captureNode)
        {
            string xmlName = captureNode.GroupName;
            int groupNumber;
            bool isUnnamedGroup = int.TryParse(xmlName, out groupNumber);

            /* If unnamed groups are to be skipped, then
             * don't write out their start and end elements,
             * but still try to write out their child captures,
             * in case these are named:
             */
            if (!(isUnnamedGroup && options.SkipUnnamedGroups))
            {
                if (isUnnamedGroup)
                {
                    xmlName = String.Format("Group{0}", groupNumber);
                }

                xmlName = options.ConvertedXmlName(xmlName);
                xw.WriteStartElement(xmlName);
                WritePositionElements(xw, options, captureNode.ThisCapture);
                WriteCapturedText(xw, options, captureNode);
            }

            foreach (RegexCaptureNode childNode in captureNode.ChildNodes)
            {
                WriteXmlHierarchy(xw, options, childNode);
            }

            if (!(isUnnamedGroup && options.SkipUnnamedGroups))
            {
                xw.WriteEndElement();
            }
        }

        private static void WritePositionElements(XmlWriter xw, 
            RegexToXmlOptions options, Capture cap)
        {
            if (options.WriteStartIndex)
            {
                xw.WriteAttributeString(
                    options.ConvertedXmlName("StartIndex"),
                    cap.Index.ToString());
            }

            if (options.WriteEndIndex)
            {
                xw.WriteAttributeString(
                    options.ConvertedXmlName("EndIndex"),
                    (cap.Index + cap.Length - 1).ToString());
            }

            if (options.WriteLength)
            {
                xw.WriteAttributeString(
                    options.ConvertedXmlName("Length"),
                    cap.Length.ToString());
            }
        }

        private static void WriteCapturedText(XmlWriter xw, 
            RegexToXmlOptions options, RegexCaptureNode captureNode)
        {
            /* If this is one of the matches, and it has child elements,
             * then don't write out the captured text,
             * as it could be too long and/or not desired:
             */
            if ((!captureNode.IsMatch) || (captureNode.ChildNodes.Count == 0))
            {
                if (captureNode.ChildNodes.Count > 0)
                {
                    /* Write the captured text to a "Text" sub-element: */
                    xw.WriteElementString(options.ConvertedXmlName("Text"),
                        captureNode.ThisCapture.Value);
                }
                else
                {
                    /* There are no child captures, so don't bother to 
                     * nest the captured text in a "Text" sub-element:
                     */
                    xw.WriteValue(captureNode.ThisCapture.Value);
                }
            }
        }
    }
}
