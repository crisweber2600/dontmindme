using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace AndrewTweddle.Tools.RegexToXml.Core
{
    [Serializable]
    public class RegexToXmlConversionException: Exception
    {
        public RegexToXmlConversionException()
            : base()
        {
        }

        public RegexToXmlConversionException(string message)
            : base(message)
        {
        }

        public RegexToXmlConversionException(string message, 
            Exception innerException)
            : base(message, innerException)
        {
        }

        protected RegexToXmlConversionException(SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }
    }
}
